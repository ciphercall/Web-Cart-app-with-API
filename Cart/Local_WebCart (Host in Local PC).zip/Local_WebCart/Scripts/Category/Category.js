﻿


    
//$('#SubmitId').click(function () {
   
//    var categoryName = $("#categoryName").val();

//    var levelGroup = $("#levelGroup").val();
  
//    $.ajax({
//        url: '/api/CategoryCreate/',
//        type: 'GET',
//        cache: false,
//        data: { CategoryName: categoryName, LevelGroup: levelGroup},
//        dataType: 'json',
//        success: function (data) {


//            alert("Saved");


//        }

//    });

//    $("#categoryName").val("");
//    $("#levelGroup").val("");
    
//});